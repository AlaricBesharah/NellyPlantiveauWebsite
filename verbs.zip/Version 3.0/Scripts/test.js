
/**
 * This function will check which groups and irregular verbs are checked 
 * and return the index in which verb the quiz needs to use. 
 */
function testBoi(){

        // Fetch la list of all the verb groups that are selected
        
        // Select a group out of the 4 options

        // Select a verb in the selected group
            // Determine checked verbs in irregular group if irregular group is selected

        // Search for the selected verb in the first colomn of the selected tense.

        // Return index at which the verb appears. 

}
